util.py
=======

.. automodule:: lib.util
   :members:
