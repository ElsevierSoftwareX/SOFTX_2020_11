max\_p\_functions.py
=====================

.. automodule:: lib.max_p_functions
   :members:
