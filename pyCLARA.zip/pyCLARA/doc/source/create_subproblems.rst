create\_subproblems.py
=======================

.. automodule:: lib.create_subproblems
   :members:
