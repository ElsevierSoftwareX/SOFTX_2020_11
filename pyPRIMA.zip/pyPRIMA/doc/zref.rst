.. only:: html

   .. rubric:: References
   
   Bibliography
   ============

.. bibliography:: refs.bib
   :all:
   :style: plain






