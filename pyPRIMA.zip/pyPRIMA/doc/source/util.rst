util.py
=======

.. automodule:: lib.util
   :members:
   :undoc-members:
   :show-inheritance:
